<!DOCTYPE html>
<html lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <title>Frequentations</title>
</head>
<body>
   <h1 class="titre"> Fréquentations </h1>    
   </body>


 <?php
$var= $_GET["gare"];
echo $var;
?>
<p></p>
 <?php


$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from frequentation where nom_gare="'.$var.'"');
echo "<table class='table'>";
echo "<tr>";



echo "<th></th>";
echo "</tr>";
while ($line = $rep ->fetch()) {
	echo $line["CLASSE_AGE"]."<br/>\n";
echo "<tr>";

}
echo "</table>";
$rep ->closeCursor();
?>
 
      <p>
        <a href="accueil.php">Accueil </a></p>

    </p>
	     <p>
        <a href="profil.php">Mon Profil </a>
    </p>
   
  </html>