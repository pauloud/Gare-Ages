<?php
 session_start();
 ?>

<!DOCTYPE html>
<html lang>
	
	<head>
		<form method="get" action="inscription.php" autocomplete="off">
		
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
	</head>
	
	<body>
		<h1>Voy'ages</h1>
		<h2> Mes informations personnelles</h2>

		
		<?php
		

if (isset($_SESSION['utilisateur'])){
          echo"Vous êtes connecté(e)s en tant que";
		  echo " ";
		  echo $_SESSION['utilisateur']['nom'];
		  echo " ";
	      echo $_SESSION['utilisateur']['prenom'];
		  echo"<br>";
		  echo "Votre numéro de téléphone est le  ";
		  echo $_SESSION['utilisateur']['num'];
		  echo"<br>";
		  echo "Votre adresse e-mail : ";
		  echo $_SESSION['utilisateur']['mail'];
		    echo"<br>";
		echo "Classe d'âge renseignée : ";
		  echo $_SESSION['utilisateur']['classe'];
echo"<br>";
	
	      echo'<a href="deconnexion.php">Déconnexion</a>';
		  

	}

?>

		
		
		
		
		<br> <p><a href="ville.php">Choisir une ville </a></p> </br>
	</body>
</html>