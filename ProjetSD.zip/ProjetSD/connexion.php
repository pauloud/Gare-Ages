<?php
 session_start();
 ?>
<!DOCTYPE HTML>
<HTML>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<TITLE>connexion</TITLE>

</HEAD>
<body>

	</head>
	
	<body>
		<h1> VOY'AGES </h1>
		 <img width=200px src ="images/gare.jpg" alt="photo"> 
		
			<form method="post" action="connecter.php" autocomplete="off">
		
		<p> Adresse email : <INPUT type="text" name="email" value=""></p>
		<p> Mot de passe : <INPUT type="password" name="mdp" value=""/> </p>
		<p> <INPUT type="submit" value="Se connecter"></p>
		
		<div class="menu">
		<p> <p><a href="profil.php">Mon profil</a></p> </br>
		<p><a href="accueil.php">Page d'accueil </a></p> </br>
		<p><a href="inscription.php">S'inscrire </a></p>
		</div>




</body>
</html>
