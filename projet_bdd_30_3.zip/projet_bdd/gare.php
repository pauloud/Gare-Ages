<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
 <form method="get" action="resultat.php" autocomplete="off">

    <title>gare </title>
</head>
<body>
   <h1 class="titre">Gares</h1> 
	<p class="comentaire"> Choisissez la gare qui vous intéresse afin de voir les correspondances possibles.</p></br>   

 <?php

$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
echo "Une fois à ";
$variable= $_GET["ville"];
echo $variable;
echo ", vous pouvez vous rendre à :";

$rep = $bdd->query('select * from gare where ville_gare= "'.$variable.'" ');
echo "<table class= cMonTableau>";
echo "<tr>";

echo "<th></th>";
echo "</tr>";

while ($line = $rep ->fetch()) {
	echo "<th><a href='resultat.php?ville=".$variable."&gare=".$line["nom_gare"]."'>".$line["nom_gare"]."</a></th>";
echo "</tr>";
}

echo "</table>";
$rep ->closeCursor();
?>





		<p><a href="ville.php">Retour à la page ville</a></p>
        <p><a href="profil.php">Mon Profil </a></p>
  
</body>
</html>