<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <title>gare </title>
</head>
<body>
   <h1 class="titre">page gare</h1>    


 <?php

$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from gare');
echo "<table class='table'>";
echo "<tr>";

echo "<th> nom des gares</th>";

echo "<th></th>";
echo "</tr>";
while ($line = $rep ->fetch()) {
echo "<tr>";
echo $line["nom_gare"];
echo "<th><a href='resultat.php?UIC=".$line["UIC"]."'>".$line["NOM_GARE"]."</a></th>";

echo "</tr>";
}
echo "</table>";
$rep ->closeCursor();
?>
 
      <p>
        <a href="Accueil.php">Retour à la page d'acceuil </a>
    </p>
  
</body>
</html>