<!DOCTYPE HTML>
<HTML>
<HEAD>
<TITLE> ville </TITLE>

		
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</HEAD>

ville
<SELECT name="ville">
<OPTION
VALUE=""></OPTION>
<OPTION
VALUE="PARIS">PARIS </OPTION>
<OPTION
VALUE="LYON">LYON </OPTION>
<OPTION
VALUE="MONTPELLIER"> MONTPELLIER</OPTION>
<OPTION
VALUE="PERPIGNAN">PERPIGNAN </OPTION>
<OPTION
VALUE="GRENOBLE"> GRENOBLE</OPTION>
<OPTION
VALUE="PARIS">PARIS </OPTION>
<OPTION
VALUE="NANCY"> NANCY</OPTION>
<OPTION
VALUE="LILLE">LILLE </OPTION>
<OPTION
VALUE="AVIGNON">AVIGNON</OPTION>
<OPTION
VALUE="LENS"> LENS</OPTION>
<OPTION
VALUE="TOULOUSE">TOULOUSE </OPTION>
<OPTION
VALUE="BORDEAUX">BERDEAUX </OPTION>
<OPTION
VALUE="">POITIERS POITIERS</OPTION>
<OPTION
VALUE="BAYONNE"> BAYONNE</OPTION>
<OPTION
VALUE="HENDAYE">HENDAYE </OPTION>
<OPTION
VALUE="DIJON"> DIJON</OPTION>
<OPTION
VALUE="MARSEILLE"> MARSEILLE</OPTION>
<OPTION
VALUE="ARLES">ARLES </OPTION>
<OPTION
VALUE="Angoulême">Angoulême </OPTION>
<OPTION
VALUE="	Tours"> Tours</OPTION>
<OPTION
VALUE="Nantes"> Nantes</OPTION>
<OPTION
VALUE="LAVAL"> LAVAL</OPTION>
<OPTION
VALUE="Rennes"> Rennes</OPTION>
<OPTION
VALUE="LORIENT"> LORIENT</OPTION>
<OPTION
VALUE="Caen"> Caen</OPTION>
<OPTION
VALUE="Cherbourg">Cherbourg </OPTION>
<OPTION
VALUE="	Biarritz"> Biarritz</OPTION>
<OPTION
VALUE="Rouen">Rouen </OPTION>
<OPTION
VALUE="Toulon">Toulon</OPTION>
<OPTION
VALUE="Nice"> Nice</OPTION>
<OPTION
VALUE="Cannes"> Cannes</OPTION>
<OPTION
VALUE="Valence "> Valence </OPTION>
<OPTION
VALUE="Nîmes"> Nîmes</OPTION>
<OPTION
VALUE="Perpignan">Perpignan </OPTION>
<OPTION
VALUE="Toulon"> Toulon </OPTION>
<OPTION
VALUE=""> </OPTION><OPTION

</SELECT>


<br> <p> <a href="profil.php"> Mon profil </a> </p> </br>
<form
action="page_gare.php" method="get" autocomplete="off">
<br> <INPUT type="submit" value="continuer"></br>
</HTML>