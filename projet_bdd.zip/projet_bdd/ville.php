<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Villes </title>
</head>
<body>
   <h1 class="titre">villes </h1>    

   <?php

 <?php

$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from ville');
echo "<table class='table'>";
echo "<tr>";
echo "<th>id_v</th>";
echo "<th> nom</th>";
echo "</tr>";
while ($line = $rep ->fetch()) {
echo "<tr>";
echo "<th>id_v</th>";
echo "<th><a href='accueil.php?id_v=".$line["id_v"]."'>".$line["nom"]."</a></th>";

echo "</tr>";
}
echo "</table>";
$rep ->closeCursor();
?>
 
 
?>
        

      <p>
        <a href="Accueil.php">Retour à la page d'acceuil </a>
    </p>
  
</body>
</html>