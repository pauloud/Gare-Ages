<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">

<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />


    <title>Page Villes </title>
</head>
<body>
   <h1 class="titre">villes </h1>    



 <?php


$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from ville');
echo "<table class='table'>";
echo "<tr>";

echo "<th> nom des villes</th>";

echo "<th></th>";
echo "</tr>";
while ($line = $rep ->fetch()) {
echo "<tr>";

echo "<th><a href='gare.php?id_v=".$line["id_v"]."'>".$line["nom"]."</a></th>";

echo "</tr>";
}
echo "</table>";
$rep ->closeCursor();
?>
 

        

      <p>
        <a href="Accueil.php">Retour à la page d'acceuil </a>
    </p>
  
</body>
</html>