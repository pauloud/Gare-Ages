<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Villes </title>
</head>
<body>
   <h1 class="titre">villes </h1>    

   <?php

	echo "vous avez choisis la ville ", $_POST['continuer'] ;
	

 
 
?>
        

      <p>
        <a href="Accueil.php">Retour à la page d'acceuil </a>
    </p>
  
</body>
</html>