<?php
 session_start();
 ?>

<!DOCTYPE HTML>
<HTML>
<HEAD>
<TITLE>resultats ville</TITLE>
<link rel="stylesheet"    href="style.css"    type="text/css"    media="screen"    />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</HEAD>
<body>
 <?php

echo "Les informations incontournables sur la ville de ";
$variable= $_GET["ville"];
echo $variable;
echo " !";
?>

<p></p>

<?php
$bdd= new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from ville where nom="'.$variable.'"');
echo "<table class='table'>";
echo "<tr>";



echo "<th></th>";
echo "</tr>";
while ($line = $rep ->fetch()) {
	echo $line["nom"];
	echo " se situe dans la région ";
	echo $line["region"];
	echo "."."<br/>\n";
	echo " Cette ville ne compte pas moins de ";
	echo $line["population"];
	echo " habitants pour un taux de chômage avoisinant les ";
	echo $line["chomage"];
	echo " %. "."<br/>\n";
	echo $line["description"]."<br/>\n";
	
echo "<tr>";

}
echo "</table>";
$rep ->closeCursor();
?>


<a href="accueil.php">Accueil</a>
<p><a href="resultat.php">Résultats </a>
     <p>
        <a href="profil.php">Mon Profil </a>
    </p>

</body>
</html>
