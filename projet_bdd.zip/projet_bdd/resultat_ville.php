<?php
 session_start();
 ?>

<!DOCTYPE HTML>
<HTML>
<HEAD>
<TITLE>resultats ville</TITLE>
<link rel="stylesheet"    href="style.css"    type="text/css"    media="screen"    />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</HEAD>
<body>
<?php

$variable =  $_GET['id_v']; 
echo "bonjour";
echo $variable;
$bdd = new PDO('mysql:host=localhost;dbname=projetgares;charset=utf8', 'root', 'root');
$rep = $bdd->query('select * from ville where id_v = '.$variable.' ');
echo $rep;

echo"maaaae";
echo "<table border=1>";
echo "<tr>";

echo "<th>nom</th>";
echo "<th>region</th>";
echo "<th>chomage</th>";
echo "<th>description</th>";
echo "</tr>";
while ($ligne = $rep ->fetch())
{
    echo "<tr>";
	echo "<td>".$ligne["nom"]."</td>";
	echo "<td>".$ligne["region"]."</td>";
	echo "<td>".$ligne["population"]."</td>";
	echo "<td>".$ligne["chomage"]."</td>";
	echo "<td>".$ligne["description"]."</td>";
	
    echo "</tr>";
}
echo "</table>";
$rep ->closeCursor();
?>


<a href="accueil.php">Retour à l'accueil</a>

</body>
</html>
