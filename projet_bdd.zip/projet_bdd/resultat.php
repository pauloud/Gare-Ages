<!DOCTYPE html>
<html lang>
<HEAD>			
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
 

<style>


.mame {
  background-color: red ;
  overflow: auto;
}
.mame a {
  float: left;;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
}

</style>

   <div class="mame">
  <a class="active" href="accueil.php">   Accueil    </a>
  <a href="resultat_ville.php?id_v=".$line['id_v']">    informations sur les villes    </a>
  <a href="resultat_transport.php">    transports à proximité     </a>
  <a href="autres.php">    autre informations     </a>
</div> 
</head>

.php?UIC=".$line["UIC"]
<body>




site .................
</body>
 </HTML>