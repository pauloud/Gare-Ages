<?php
 session_start();
 ?>
<!DOCTYPE HTML>
<HTML>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<TITLE>connexion</TITLE>

</HEAD>
<body>

	</head>
	
	<body>
		<h1> GAR'AGES </h1>
		 <img width=200px src ="images/gare.jpg" alt="photo"> 
		
			<form method="get" action="ville.php" autocomplete="off">
		
		<p> Adresse email : <INPUT type="text" name="email" value=""></p>
		<p> Mot de passe : <INPUT type="password" name="mdp" value=""/> </p>
		<p> <INPUT type="submit" value="Se connecter"></p>
		
		<div class="menu">
		<p> <p><a href="accueil.php">cliquez pour retouirner à la page d'accueil </a></p> </br>
		<p> <p><a href="inscription.php">si vous n'avez pas encore créer de compte veuiller cliquer ici pour vous inscrire svp </a></p>
		</div>




</body>
</html>
