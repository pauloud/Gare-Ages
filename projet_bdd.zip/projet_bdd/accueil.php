<!DOCTYPE html>
<html lang>
			
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
 

</HEAD>
<style>
  .slider{
    width:200px;
    overflow:hidden;
    margin:150px auto;
  }
  .slides {
    width: calc(200px * 3);
    animation: glisse 5s infinite;
  }
  .slide{
    float:left;
  }
  @keyframes glisse {
    0% {
      transform: translateX(0);
    }
    10% {
      transform: translateX(0);
    }
    33% {
      transform:translateX(-200px);
    }
    43% {
      transform:translateX(-200px);
    }





  }
</style>
<body>

<div id="haut">
<H1 class="titre">bienvenu dans notre site </H1>
</div>
<div id="milieu">
<p>choisissez</p>
<p class="comentaire">Notre site met tout en place afin de satisfaire ses clients. préparez vos voyages patrtout en France
	

<div class="slider">
  <div class="slides">
    <div class="slide"><img width=200px src="vu.jpeg" alt="gare" /></div>
    <div class="slide"><img width=200px src="ville.jpg" alt="ville" /></div>



<div id="bas">
<a href="profil.php">profil</a></br>

<a href="connexion.php">se connecter</a></br>

</div>


	
	
	</body>
	
</html>