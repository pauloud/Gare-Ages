	<?php
	include 'bd.php';
	?>

<?php
 session_start();
 ?>



<!DOCTYPE html>
<html lang>
<HEAD>			
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
 

</HEAD>
<style>
  .slider{
    width:200px;
    overflow:hidden;
    margin:150px auto;
  }
  .slides {
    width: calc(200px * 3);
    animation: glisse 5s infinite;
  }
  .slide{
    float:left;
  }
  @keyframes glisse {
    0% {
      transform: translateX(0);
    }
    10% {
      transform: translateX(0);
    }
    33% {
      transform:translateX(-200px);
    }
    43% {
      transform:translateX(-200px);
    }

	#gueye{
	background-image: url(images/voyage.jpeg);
	background-repeat : no-repeat;
	}

  }
</style>
<body id="gueye">

<div id="haut">
<H1 class="titre">bienvenu dans notre site </H1>
</div>
<div id="milieu">

<p class="comentaire">Notre site met tout en place afin de satisfaire ses clients. préparez vos voyages partout en France</p></br>
	


 <div class="slides">
 
    <div class="slide"><img width=200px src="images\vu.jpeg" alt="gare" /></div>
	
    <div class="slide"><img width=200px src="images\ville.jpg" alt="ville" /></div>
	
    <div class="slide"><img width=200px src="images\gare.jpg" alt="ville" /></div>
	

 </div>


<div class="menu">

<a href="inscription.php">cliquer ici pour vous inscrire s'inscrire</a></br>

<a href="connexion.php">se connecter</a></br>

<a href="ville.php">acceder directement au site</a></br>


</div>


	
	
	</body>
	
</html>