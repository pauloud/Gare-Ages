<!DOCTYPE HTML>
<HTML>
<HEAD>
<TITLE> gare </TITLE>

		
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</HEAD>

gare
<SELECT name="gare">
<OPTION
VALUE="Marne la Vallée Chessy"> Marne la Vallée Chessy </OPTION>
<OPTION
VALUE="Paris Bercy"> Paris Bercy </OPTION>
<OPTION
VALUE="Troyes"> Troyes </OPTION>
<OPTION
VALUE="Nancy"> Nancy </OPTION>
<OPTION
VALUE="Lorraine TGV"> Lorraine TGV </OPTION>
<OPTION
VALUE="	Reims"> Reims </OPTION>
<OPTION
VALUE="	Reims"> Reims </OPTION>
<OPTION
VALUE="Colmar"> Colmar </OPTION>
<OPTION
VALUE="Mulhouse"> Mulhouse </OPTION>
<OPTION
VALUE="Metz"> Metz </OPTION>
<OPTION
VALUE="Strasbourg"> Strasbourg </OPTION>
<OPTION
VALUE="Lille Europe"> Lille Europe </OPTION>
<OPTION
VALUE="Paris Nord"> Paris Nord </OPTION>
<OPTION
VALUE="Aéroport Charles de Gaulle 2 TGV">Aéroport Charles de Gaulle 2 TGV  </OPTION>
<OPTION
VALUE="Lille Flandres">Lille Flandres  </OPTION>
<OPTION
VALUE="Belfort Montbéliard TGV">Belfort Montbéliard TGV  </OPTION>
<OPTION
VALUE="Besançon Franche-Comté TGV">Besançon Franche-Comté TGV  </OPTION>
<OPTION
VALUE="	Amiens"> Amiens </OPTION>
<OPTION
VALUE="Avignon TGV">Avignon TGV  </OPTION>
<OPTION
VALUE="Aix en Provence-TGV">Aix en Provence-TGV  </OPTION>
<OPTION
VALUE="Lens">Lens</OPTION>
<OPTION
VALUE="Paris St Lazare">Paris St Lazare  </OPTION>
<OPTION
VALUE="Paris Montparnasse 1 et 2 + Vaugirard">Paris Montparnasse 1 et 2 + Vaugirard  </OPTION>
<OPTION
VALUE="Massy TGV"> Massy TGV </OPTION>
<OPTION
VALUE="Le Mans"> Le Mans </OPTION>
<OPTION
VALUE="Rouen Rive Droite"> Rouen Rive Droite </OPTION>
<OPTION
VALUE="Caen"> Caen </OPTION>
<OPTION
VALUE="Cherbourg"> Cherbourg </OPTION>
<OPTION
VALUE="	
Toulon"> Toulon</OPTION>
<OPTION
VALUE="Nice"> Nice</OPTION>

<OPTION
VALUE="Cannes"> Cannes</OPTION>

<OPTION
VALUE="Lyon Saint Exupery TGV"> Lyon Saint Exupery TGV</OPTION>
<OPTION
VALUE="Valence TGV Rhône-Alpes Sud"> Valence TGV Rhône-Alpes Sud</OPTION>
<OPTION
VALUE="Montpellier Saint-Roch"> Montpellier Saint-Roch</OPTION>
<OPTION
VALUE="Nîmes"> Nîmes</OPTION>
<OPTION
VALUE="Perpignan"> Perpignan</OPTION>
<OPTION
VALUE="Arles"> Arles</OPTION>
<OPTION
VALUE="	
Marseille Saint-Charles"> Marseille Saint-Charles</OPTION>
<OPTION
VALUE="Grenoble">Grenoble </OPTION>
<OPTION
VALUE="Lyon Part Dieu"> Lyon Part Dieu</OPTION>
<OPTION
VALUE="Lyon Perrache"> Lyon Perrache</OPTION>
<OPTION
VALUE="Besançon-Viotte"> Besançon-Viotte</OPTION>
<OPTION
VALUE="Dijon"> Dijon</OPTION>
<OPTION
VALUE="Paris Gare de Lyon"> Paris Gare de Lyon</OPTION>
<OPTION
VALUE="Hendaye"> Hendaye</OPTION>
<OPTION
VALUE="Biarritz"> Biarritz</OPTION>
<OPTION
VALUE="	Bayonne"> Bayonne</OPTION>
<OPTION
VALUE="Toulouse Matabiau"> Toulouse Matabiau</OPTION>
<OPTION
VALUE="Angoulême"> Angoulême</OPTION>
<OPTION
VALUE="Bordeaux Saint-Jean"> Bordeaux Saint-Jean</OPTION>
<OPTION
VALUE="Poitiers"> Poitiers</OPTION>
<OPTION
VALUE="Tours"> Tours</OPTION>
<OPTION
VALUE="	Paris Austerlitz"> Paris Austerlitz</OPTION>
<OPTION
VALUE="Angers Saint Laud"> Angers Saint Laud</OPTION>
<OPTION
VALUE="Nantes"> Nantes</OPTION>
<OPTION
VALUE="Laval"> Laval</OPTION>
<OPTION
VALUE="Lorient">Lorient</OPTION>
<OPTION
VALUE="Rennes"> Rennes</OPTION>
<OPTION
VALUE=""> Montpellier Sud de France</OPTION>
<OPTION
VALUE=""> </OPTION>
<OPTION
VALUE=""> </OPTION>
<OPTION
VALUE=""> </OPTION>
<OPTION
VALUE=""> </OPTION>
<OPTION
VALUE=""> </OPTION>
<OPTION
VALUE=""> </OPTION>


</SELECT>
<Br><p> <a href = " profil.php " > Mon  profil </a> </p> </br>
<form
action="ville.php" method="get" autocomplete="off">
<br> <INPUT type="submit" value="continuer"></br>

</HTML>