<?php
 session_start();
 ?>

<!DOCTYPE html>
<html lang>
	
	<head>
		<form method="get" action="inscription.php" autocomplete="off">
		
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
	</head>
	
	<body>
		<h1>Voy'ages</h1>
		<h2> Mes informations personnelles</h2>

		
		<?php
		echo "mame";

if (isset($_SESSION['utilisateur'])){
          echo"Vous êtes connecté(e)s en tant que";
		  echo " ";
		  echo $_SESSION['utilisateur'][1];
		  echo " ";
	      echo $_SESSION['utilisateur'][2];
		  echo"<br>";
		  echo "Votre numéro de téléphone est le :  ";
		  echo $_SESSION['utilisateur'][3];
		  echo"<br>";
		  echo "Votre Adresse e-mail : ";
		  echo $_SESSION['utilisateur'][4];
		    echo"<br>";
		echo "classe d'age  : ";
		  echo $_SESSION['utilisateur'][5];
			
	
	      echo'<a href="deconnexion.php">Deconnexion</a>';
		  echo"fatou";

	}

?>

		
		
		
		
		<br> <p><a href="ville.php">Retour à la page ville </a></p> </br>
	</body>
</html>