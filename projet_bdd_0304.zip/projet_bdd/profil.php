<?php
 session_start();
 ?>

<!DOCTYPE html>
<html lang>
	
	<head>
		<form method="get" action="inscription.php" autocomplete="off">
		
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
	</head>
	
	<body>
		<h1>Voy'ages</h1>
		<h2> Mes informations personnelles</h2>

		
		<?php
		

if (isset($_SESSION['utilisateur'])){
          echo"Vous êtes connecté(e)s en tant que";
		  echo " ";
		  echo $_SESSION['utilisateur']['nom'];
		  echo " ";
	      echo $_SESSION['utilisateur']['prenom'];
		  echo"<br>";
		  echo "Votre numéro de téléphone est le :  ";
		  echo $_SESSION['utilisateur']['num'];
		  echo"<br>";
		  echo "Votre Adresse e-mail : ";
		  echo $_SESSION['utilisateur']['mail'];
		    echo"<br>";
		echo "classe d'age  : ";
		  echo $_SESSION['utilisateur']['classe'];
			
	
	      echo'<a href="deconnexion.php">Deconnexion</a>';
		  

	}

?>

		
		
		
		
		<br> <p><a href="ville.php">Retour à la page ville </a></p> </br>
	</body>
</html>