<?php
session_start();
session_destroy();

?>
<!DOCTYPE HTML>

<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<TITLE>page de deconnexion</TITLE>

</HEAD>
<body>

 <H1>à bientot au revoir!</H1>
 
 <a href="accueil.php">Retourner à la page d'accueil</a> 

 
</body>
</html>
