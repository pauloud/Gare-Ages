<?php include 'bd.php' ?>
<!DOCTYPE html>
<html lang="en">

<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />


    <title>Page Villes </title>
	
   <h1 class="titre">Régions </h1>  
 
 
 <p> Choisissez la région qui vous intéresse afin de voir toutes les villes disponibles et obtenir des informations !</p></br>   

	
	<script src="cmap/france-map.js"></script>

	<script>francefree();</script>   

<style>
a:hover {background-color:red;}

</style>
	

</head>

<body>

        <p><a href="accueil.php">Page d'accueil </a></p>
		<p><a href="deconnexion.php">Se déconnecter </a></p>
  </body>

</html>