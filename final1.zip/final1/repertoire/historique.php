<html>
<body>
<img src="graph_1.php"/>
<img src="graph_2.php"/>
</body>
</html>