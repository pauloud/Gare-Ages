<?php
session_start();
session_destroy();

?>
<!DOCTYPE HTML>

<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<TITLE>page de deconnexion</TITLE>

</HEAD>
<body>
<h1> VOY'AGES </h1>

<img width=400px src ="images/gare.jpg" alt="photo"> 

 <H1>A bientot !</H1>
 
 <a href="accueil.php">Page d'accueil</a> 

 
</body>
</html>
