<head>

<?php 


function enregistrer($n, $p, $adr, $num, $mail, $mdp){
    
    //connexion
    include('bd.php');
    $bdd = getBD();
    //insertion
    $requete = "INSERT INTO utilisateur (nom, prenom,adresse,numero,mail,mdp) values ('$n', '$p', '$adr', '$num', '$mail', '$mdp')";

    $bdd->query($requete); 
    
}


if($_GET['mdp1'] == '' || $_GET['mdp2'] == '' || $_GET['mdp1'] != $_GET['mdp2'] || $_GET['n'] == '' || $_GET['p'] == ''|| $_GET['adr'] == ''|| $_GET['mail'] == '') {

?>
<meta http-equiv="refresh" content="0;URL=inscription.php?n=<?php echo $_GET['n'] ?>&p=<?php echo $_GET['p'] ?>&adr=<?php echo $_GET['adr'] ?>&num=<?php echo $_GET['num'] ?>&mail=<?php echo $_GET['mail'] ?>"/> 
<?php 
} else {
    enregistrer($_GET['n'], $_GET['p'], $_GET['adr'], $_GET['num'], $_GET['mail'], $_GET['mdp1'] );
    
?>
<meta http-equiv="refresh" content="0;URL=ville.php" /> 

<?php
} 
?>

?>
</head>